package com.curso.spring.mvc;

public interface Servicio {

	String saludar(String string);

}
