package com.curso.modelo.negocio.excepcion;

public class DatosPeliculaException extends Exception {

	public DatosPeliculaException(String message) {
		super(message);
	}

}
