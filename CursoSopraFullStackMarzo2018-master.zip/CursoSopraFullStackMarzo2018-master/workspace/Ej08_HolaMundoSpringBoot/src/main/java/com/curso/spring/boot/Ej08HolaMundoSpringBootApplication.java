package com.curso.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej08HolaMundoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej08HolaMundoSpringBootApplication.class, args);
	}
}
