package com.ejemplo.arquitectura.cloud;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Configuracion {
	//http://user:password@localhost:8080/
	/*@Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
         return new BasicAuthRequestInterceptor("user", "passwordholamundo");
    }*/
}

