package com.oauth.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthAplicacion {
	public static void main(String[] args) {
		SpringApplication.run(OauthAplicacion.class, args);
	}
}