package com.example.demo;

public interface IServicioDos {

	void tarea();

}