package com.example.demo;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
//@EnableWebMvc
public class Configuracion implements WebMvcConfigurer {

	
	
	/*@Bean
	public Negocio negocio() {
		return new NegocioImpl();
	}
	
	@Bean
	public Negocio negocio1() {
		return new NegocioImpl();
	}*/
}
