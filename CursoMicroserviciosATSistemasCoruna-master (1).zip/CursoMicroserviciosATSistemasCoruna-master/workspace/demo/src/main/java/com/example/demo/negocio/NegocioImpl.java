package com.example.demo.negocio;

import org.springframework.stereotype.Component;

@Component
public class NegocioImpl implements Negocio {

	@Override
	public void hacerCosas() {
		// TODO Auto-generated method stub
	}

}
