package com.example.demo.negocio;

public interface Negocio {

	void hacerCosas();

}
