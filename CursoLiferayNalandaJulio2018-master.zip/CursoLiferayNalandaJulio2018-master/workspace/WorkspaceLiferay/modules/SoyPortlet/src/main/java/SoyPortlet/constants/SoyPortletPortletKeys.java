package SoyPortlet.constants;

/**
 * @author Victor
 */
public class SoyPortletPortletKeys {

	public static final String SoyPortlet = "SoyPortlet";

}