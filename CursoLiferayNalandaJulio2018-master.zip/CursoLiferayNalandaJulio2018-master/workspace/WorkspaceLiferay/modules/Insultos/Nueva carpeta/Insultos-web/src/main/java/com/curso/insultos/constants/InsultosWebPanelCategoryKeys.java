package com.curso.insultos.constants;

/**
 * @author Victor
 */
public class InsultosWebPanelCategoryKeys {

	public static final String CONTROL_PANEL_CATEGORY = "InsultosWeb";

}