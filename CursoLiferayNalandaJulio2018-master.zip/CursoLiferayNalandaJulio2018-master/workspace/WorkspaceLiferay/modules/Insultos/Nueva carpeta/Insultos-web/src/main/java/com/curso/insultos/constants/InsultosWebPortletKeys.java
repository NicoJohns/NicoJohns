package com.curso.insultos.constants;

/**
 * @author Victor
 */
public class InsultosWebPortletKeys {

	public static final String InsultosWeb = "InsultosWeb";

}