package com.ejemplo.liferay.application;

public interface ServicioSaludos {

	String morning(String name, String drink);

	String hello();

	Persona working();

}
