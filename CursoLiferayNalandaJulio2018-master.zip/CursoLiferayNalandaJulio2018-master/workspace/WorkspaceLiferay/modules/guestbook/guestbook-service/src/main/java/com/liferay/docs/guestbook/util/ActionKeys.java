package com.liferay.docs.guestbook.util;

public class ActionKeys
	extends com.liferay.portal.kernel.security.permission.ActionKeys {

	public static final String ADD_ENTRY = "ADD_ENTRY";
	public static final String ADD_GUESTBOOK = "ADD_GUESTBOOK";
}
