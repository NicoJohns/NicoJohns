package com.liferay.curso.constants;

/**
 * @author Victor
 */
public class CustomPortletKeys {

	public static final String Custom = "Custom";

}