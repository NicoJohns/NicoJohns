package com.curso.maven.unitarias;

import static org.junit.Assert.*;

import org.junit.Test;

public class PruebaUnitaria {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
