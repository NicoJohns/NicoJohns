package com.ejemplo.spring.jdbc.persistencia;

import java.util.List;

import com.ejemplo.spring.jdbc.entities.Factura;

public class FacturaJpaDao implements FacturaDao {

	public long insertar(Factura factura) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Factura> consultatodo() {
		return null;
	}

	public Factura consultaPorId(long id) {
		return null;
	}

}
