package com.ejemplo;

public class TargetImpl implements Target{

	@Override
	public void hazAlgo() {
		System.out.println("En el Target");
		
	}

}
