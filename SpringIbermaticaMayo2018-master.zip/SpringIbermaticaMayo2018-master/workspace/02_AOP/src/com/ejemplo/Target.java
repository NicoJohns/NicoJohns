package com.ejemplo;

//El elemento al que se quiere acceder
public interface Target {

	void hazAlgo();

}
