package es.curso.spring.basico.servicios;

public interface Servicio {

	void saludar();

}
