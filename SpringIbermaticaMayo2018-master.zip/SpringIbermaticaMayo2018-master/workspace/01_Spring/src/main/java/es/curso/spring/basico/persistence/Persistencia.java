package es.curso.spring.basico.persistence;

public interface Persistencia {

	String obtenerSaludo();

}
