package com.atsistemas;


public class Negocio {

	public String metodo(String dato){
		System.out.println("Estoy en el bean negocio con dato = " + dato);
		return null;
	}

	public String otroMetodo(String dato){
		System.out.println("Estoy en el bean negocio con dato = " + dato);
		return null;
	}
	
}
