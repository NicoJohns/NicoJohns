package com.atsistemas;

public class AspectoAntes {
	public void antesDeServicio(String parametro){
		System.out.println("parametro " + parametro);
	}
}
