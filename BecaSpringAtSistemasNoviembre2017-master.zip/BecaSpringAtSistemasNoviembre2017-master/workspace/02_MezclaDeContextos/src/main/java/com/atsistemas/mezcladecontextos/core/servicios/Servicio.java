package com.atsistemas.mezcladecontextos.core.servicios;

public interface Servicio {

	void ejecutarRequisito();

}