package com.atsistemas.mezcladecontextos.core.servicios;

public class ServicioBasico implements Servicio {

	@Override
	public void ejecutarRequisito() {
		// TODO Auto-generated method stub
		System.out.println("Ejecutando Requisito");
	}

}
