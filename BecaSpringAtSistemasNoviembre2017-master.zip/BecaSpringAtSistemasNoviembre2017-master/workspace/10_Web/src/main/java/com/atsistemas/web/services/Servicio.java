package com.atsistemas.web.services;

public class Servicio {
	public String metodo() {
		return "Desde el servicio creado por Spring";
	}
}
