package com.atsistemas.propiedades.core.entidades;

public class Persona {

}
