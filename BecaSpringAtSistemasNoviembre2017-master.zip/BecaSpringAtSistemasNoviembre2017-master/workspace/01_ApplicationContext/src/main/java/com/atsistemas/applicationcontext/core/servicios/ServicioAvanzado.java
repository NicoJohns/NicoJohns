package com.atsistemas.applicationcontext.core.servicios;

public class ServicioAvanzado implements Servicio {

	@Override
	public void ejecutarRequisito() {
		// TODO Auto-generated method stub
		System.out.println("Ejecutando Requisito Avanzadamente");
	}

}
