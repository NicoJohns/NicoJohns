package com.atsistemas.applicationcontext.core.servicios;

public interface Servicio {

	void ejecutarRequisito();

}