package com.atsistemas.factoria.core.entidades;

public class Renault implements Coche {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub

	}

}
