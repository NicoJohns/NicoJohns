package com.atsistemas.factoria.core.entidades;

public class Empleado {

}
