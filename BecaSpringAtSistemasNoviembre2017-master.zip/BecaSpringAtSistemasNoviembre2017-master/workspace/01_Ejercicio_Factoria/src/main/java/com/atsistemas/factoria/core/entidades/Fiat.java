package com.atsistemas.factoria.core.entidades;

public class Fiat implements Coche {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub

	}

}
