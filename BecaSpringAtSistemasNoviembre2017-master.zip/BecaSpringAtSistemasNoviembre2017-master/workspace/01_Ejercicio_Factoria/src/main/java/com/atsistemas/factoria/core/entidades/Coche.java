package com.atsistemas.factoria.core.entidades;

public interface Coche {

	void acelerar();
	
}
