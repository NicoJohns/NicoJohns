package com.atsistemas.factoria.core.entidades;

public class Ferrari implements Coche {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub

	}

}
