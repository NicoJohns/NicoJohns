package com.atsistemas;

public interface INegocio {

	String metodo(String dato);

}