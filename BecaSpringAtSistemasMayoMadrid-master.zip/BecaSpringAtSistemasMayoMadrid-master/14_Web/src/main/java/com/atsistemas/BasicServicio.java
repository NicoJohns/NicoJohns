package com.atsistemas;

public class BasicServicio implements Servicio {

	@Override
	public String altaUSuario() {
		// TODO Auto-generated method stub
		return "Hemos llegado al servicio";
	}

}
