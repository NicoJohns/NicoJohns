package com.atsistemas;

public interface Servicio {

	String altaUSuario();

}
