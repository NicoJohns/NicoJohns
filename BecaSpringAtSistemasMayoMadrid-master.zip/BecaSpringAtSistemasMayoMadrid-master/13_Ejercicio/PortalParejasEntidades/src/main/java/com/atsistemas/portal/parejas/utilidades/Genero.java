package com.atsistemas.portal.parejas.utilidades;

public enum Genero {
	MASCULINO, FEMENINO
}
