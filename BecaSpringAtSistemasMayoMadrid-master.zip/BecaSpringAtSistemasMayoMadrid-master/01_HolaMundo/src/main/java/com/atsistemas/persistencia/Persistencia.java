package com.atsistemas.persistencia;

import com.atsistemas.Persona;

public interface Persistencia {
	void guardar(Persona persona);
	// ...
}
