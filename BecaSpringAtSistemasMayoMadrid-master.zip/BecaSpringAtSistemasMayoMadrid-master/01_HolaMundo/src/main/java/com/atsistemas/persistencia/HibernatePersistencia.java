package com.atsistemas.persistencia;

import com.atsistemas.Persona;

public class HibernatePersistencia implements Persistencia {

	@Override
	public void guardar(Persona persona) {
		// TODO Auto-generated method stub

	}

}
