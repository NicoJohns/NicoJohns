package com.atsistemas.servicios;

public interface Servicio {

}
