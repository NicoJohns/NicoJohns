package com.atsistemas.ejercicio.vista;

public class VistaError implements Vista {

	public VistaError(Exception e) {
		// TODO Auto-generated constructor stub
	}

}
