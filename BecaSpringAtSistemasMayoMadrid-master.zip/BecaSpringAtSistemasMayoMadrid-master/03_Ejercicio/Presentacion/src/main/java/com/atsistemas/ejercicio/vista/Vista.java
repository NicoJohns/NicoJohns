package com.atsistemas.ejercicio.vista;

public interface Vista {

}
