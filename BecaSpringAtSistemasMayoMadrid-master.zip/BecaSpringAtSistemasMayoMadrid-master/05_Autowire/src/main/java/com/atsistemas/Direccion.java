package com.atsistemas;

public class Direccion {
	private String calle;

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}
}
