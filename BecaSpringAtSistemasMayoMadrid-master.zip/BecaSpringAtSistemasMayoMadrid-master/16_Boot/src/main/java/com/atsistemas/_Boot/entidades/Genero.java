package com.atsistemas._Boot.entidades;

public enum Genero {
	Hombre, Mujer

}
