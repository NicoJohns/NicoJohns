package com.atsistemas.ejercicio2.persistencia;

public interface ConsultaPersonaDao {
	void selectPersonaByNombre(String nombre);
}
