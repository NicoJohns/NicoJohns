package com.atsistemas.ejercicio2.servicios;

public interface ServicioConsulta {

	void buscarPersona(String nombre);

}