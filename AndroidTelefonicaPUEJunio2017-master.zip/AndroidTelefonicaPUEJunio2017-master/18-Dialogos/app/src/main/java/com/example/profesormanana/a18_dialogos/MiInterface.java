package com.example.profesormanana.a18_dialogos;

/**
 * Created by profesormanana on 16/6/16.
 */
public interface MiInterface {
    void establecerResultadoPersonalizado(String dato);
}
