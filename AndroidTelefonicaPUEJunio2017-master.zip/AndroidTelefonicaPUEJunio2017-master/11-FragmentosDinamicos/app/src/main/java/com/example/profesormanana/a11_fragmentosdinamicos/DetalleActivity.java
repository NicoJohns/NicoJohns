package com.example.profesormanana.a11_fragmentosdinamicos;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by profesormanana on 3/6/16.
 */
public class DetalleActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);
    }
}
