package com.example.profesormanana.a03_comunicacionentreactividades;

import java.io.Serializable;

/**
 * Created by profesormanana on 25/5/16.
 */
public class Direccion implements Serializable{
}
