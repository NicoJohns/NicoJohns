package com.example.profesormanana.a10_fragmentos;

/**
 * Created by profesormanana on 3/6/16.
 */
public interface OnItemSelectedListadoCorreosListener {
    void onItemSelected(CorreoElectronico item);
}
