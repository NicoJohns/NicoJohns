package com.curso.spring.fideliza.reservas.bom;

public class Reserva {

}
