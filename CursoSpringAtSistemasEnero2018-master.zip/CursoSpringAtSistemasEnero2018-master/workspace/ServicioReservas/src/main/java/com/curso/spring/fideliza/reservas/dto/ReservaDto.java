package com.curso.spring.fideliza.reservas.dto;

public class ReservaDto {

	public Long getId() {
		// TODO Auto-generated method stub
		return null;
	}

}
