package com.curso.spring.fidelizacion.back.entities;

public class Usuario {

}
