package com.curso.spring.mvc.dto;

public enum Genero {
	MASCULINO, FEMENINO
}
