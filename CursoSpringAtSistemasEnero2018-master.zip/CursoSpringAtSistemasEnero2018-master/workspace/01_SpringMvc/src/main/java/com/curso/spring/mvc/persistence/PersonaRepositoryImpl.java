package com.curso.spring.mvc.persistence;

import org.springframework.stereotype.Repository;

import com.curso.spring.mvc.entities.Persona;

@Repository
public class PersonaRepositoryImpl implements PersonaRepository {

	/* (non-Javadoc)
	 * @see com.curso.spring.mvc.persistence.PersonaRepository#save(com.curso.spring.mvc.entities.Persona)
	 */
	@Override
	public void save(Persona unMarshall) {
		// TODO Auto-generated method stub
		
	}

}
