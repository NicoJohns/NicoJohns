package com.curso.spring.fideliza.login.dto;

public class LoginDto {

}
