package com.curso.spring.persistencia.servicios;

import com.curso.spring.persistencia.entidades.Persona;

public interface Servicio {

	void altaEnElSistemaDeUnaPersona(Persona persona);

}