package com.curso.spring.persistencia.dao.hibernate;

import com.curso.spring.persistencia.dao.ClienteDao;
import com.curso.spring.persistencia.entidades.Persona;

public class HibernateClienteDao extends HibernateDao implements ClienteDao{
	
	@Override
	public void insertarPersona(Persona persona) {
		// TODO Auto-generated method stub

	}

}
