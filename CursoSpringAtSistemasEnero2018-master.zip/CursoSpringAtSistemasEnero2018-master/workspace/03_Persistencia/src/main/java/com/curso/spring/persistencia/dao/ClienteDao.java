package com.curso.spring.persistencia.dao;

import com.curso.spring.persistencia.entidades.Persona;

public interface ClienteDao {

	void insertarPersona(Persona persona);

}