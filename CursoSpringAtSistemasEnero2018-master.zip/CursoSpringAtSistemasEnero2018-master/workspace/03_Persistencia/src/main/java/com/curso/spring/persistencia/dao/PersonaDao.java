package com.curso.spring.persistencia.dao;

import com.curso.spring.persistencia.entidades.Persona;

public interface PersonaDao {

	void insertarPersona(Persona persona);

}