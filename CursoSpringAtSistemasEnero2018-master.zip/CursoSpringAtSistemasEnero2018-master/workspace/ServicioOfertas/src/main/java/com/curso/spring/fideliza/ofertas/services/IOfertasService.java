package com.curso.spring.fideliza.ofertas.services;

import java.util.List;

import com.curso.spring.fideliza.ofertas.bom.Oferta;

public interface IOfertasService {
	public List<Oferta> consultarTodas();
}
