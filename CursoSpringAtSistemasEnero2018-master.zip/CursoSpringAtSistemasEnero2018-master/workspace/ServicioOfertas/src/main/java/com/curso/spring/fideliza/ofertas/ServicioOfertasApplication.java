package com.curso.spring.fideliza.ofertas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioOfertasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioOfertasApplication.class, args);
	}
}
