package com.curso.spring.fidelizacion.dto;

public class UsuarioDto {

}
