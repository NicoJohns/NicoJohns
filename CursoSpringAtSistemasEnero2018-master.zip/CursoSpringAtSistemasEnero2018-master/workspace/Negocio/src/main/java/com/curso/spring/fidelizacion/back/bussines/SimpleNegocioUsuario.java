package com.curso.spring.fidelizacion.back.bussines;

import com.curso.spring.fidelizacion.back.entities.Usuario;
import com.curso.spring.fidelizacion.dto.UsuarioDto;

public class SimpleNegocioUsuario implements NegocioUsuario{

	public Usuario dtoToEntidad(UsuarioDto usuarioDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
