package com.curso.spring.fideliza.presentacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresentacionTarjetaFidelizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PresentacionTarjetaFidelizaApplication.class, args);
	}
}
