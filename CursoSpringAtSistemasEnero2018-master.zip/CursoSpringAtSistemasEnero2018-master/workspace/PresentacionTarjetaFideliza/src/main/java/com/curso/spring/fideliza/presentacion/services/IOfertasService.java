package com.curso.spring.fideliza.presentacion.services;

import java.util.List;

import com.curso.spring.fideliza.presentacion.dto.Oferta;

public interface IOfertasService {
	public List<Oferta> consultarTodas();
}
