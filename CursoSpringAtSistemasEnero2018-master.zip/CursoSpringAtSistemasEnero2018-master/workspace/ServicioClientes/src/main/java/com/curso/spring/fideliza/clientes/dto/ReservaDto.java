package com.curso.spring.fideliza.clientes.dto;

public class ReservaDto {

}
