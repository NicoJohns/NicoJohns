package com.curso.spring.fidelizacion.back.persist;

import com.curso.spring.fidelizacion.back.entities.Usuario;

public interface UsuarioDao {

	void save(Usuario usuarioEntidad);

}
