package com.jersey.simpsons.core.services;

public interface Servicio {

	void funcionalidadDeLaCapaDeNegocio();
	
}
