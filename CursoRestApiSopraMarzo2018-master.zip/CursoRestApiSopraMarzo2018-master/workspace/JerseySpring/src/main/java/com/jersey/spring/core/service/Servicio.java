package com.jersey.spring.core.service;

public interface Servicio {

	void funcionalidadDeLaCapaDeNegocio();
	
}
