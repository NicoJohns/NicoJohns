#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};


import org.junit.Assert;
import org.junit.Test;


class Prueba {

	@Test
	void test() {
		Assert.fail("Not yet implemented");
	}

}
