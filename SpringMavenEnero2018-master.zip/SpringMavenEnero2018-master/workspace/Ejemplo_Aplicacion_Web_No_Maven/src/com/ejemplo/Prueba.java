package com.ejemplo;


import org.junit.Assert;
import org.junit.Test;


class Prueba {

	@Test
	void test() {
		Assert.fail("Not yet implemented");
	}

}
