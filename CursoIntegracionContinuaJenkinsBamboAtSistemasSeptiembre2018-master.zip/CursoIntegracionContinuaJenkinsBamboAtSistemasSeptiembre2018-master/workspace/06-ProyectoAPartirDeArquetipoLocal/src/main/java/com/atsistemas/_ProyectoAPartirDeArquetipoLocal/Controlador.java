package com.atsistemas._ProyectoAPartirDeArquetipoLocal;

import org.springframework.stereotype.Controller;

@Controller
public class Controlador {

}
