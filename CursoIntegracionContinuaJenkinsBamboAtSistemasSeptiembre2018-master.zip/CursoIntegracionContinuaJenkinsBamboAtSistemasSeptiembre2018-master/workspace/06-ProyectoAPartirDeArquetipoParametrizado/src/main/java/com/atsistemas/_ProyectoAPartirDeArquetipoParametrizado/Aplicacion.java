package com.atsistemas._ProyectoAPartirDeArquetipoParametrizado;

import org.springframework.stereotype.Controller;

@Controller
public class Aplicacion {

}
