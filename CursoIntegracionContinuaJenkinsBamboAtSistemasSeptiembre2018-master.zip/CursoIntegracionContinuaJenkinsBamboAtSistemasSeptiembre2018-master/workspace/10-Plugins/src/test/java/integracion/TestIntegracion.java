package integracion;

import static org.junit.Assert.*;

public class TestIntegracion {

	@org.junit.Test
	public void test() {
		//fail("Not yet implemented");
	}

}
