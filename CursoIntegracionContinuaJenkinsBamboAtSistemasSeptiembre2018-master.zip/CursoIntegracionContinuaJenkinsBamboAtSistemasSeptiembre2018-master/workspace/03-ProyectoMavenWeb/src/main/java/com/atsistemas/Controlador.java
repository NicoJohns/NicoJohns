package com.atsistemas;

import org.springframework.stereotype.Controller;

@Controller
public class Controlador {

}
