package com.accenture.transporte;

public class EntregaPedido {

}
