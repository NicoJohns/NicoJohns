package com.accenture.cobro;

public class InformacionDelCobro {

}
