package com.oauth.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteAplicacion {
	public static void main(String[] args) {
		SpringApplication.run(ClienteAplicacion.class, args);
	}
}