package com.accenture._WebBoot;

public interface Servicio {

	public void metodoDeNegocio();
	
}
