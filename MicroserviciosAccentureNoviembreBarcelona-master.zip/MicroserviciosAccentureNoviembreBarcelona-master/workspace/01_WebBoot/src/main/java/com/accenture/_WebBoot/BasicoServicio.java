package com.accenture._WebBoot;

public class BasicoServicio implements Servicio {

	@Override
	public void metodoDeNegocio() {
		// TODO Auto-generated method stub
		System.out.println("en el servicio");
	}

}
