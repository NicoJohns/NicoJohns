package com.accenture.orquestador;

public class OrdenDeCompra {

	public int getCantidad() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getTipoProducto() {
		// TODO Auto-generated method stub
		return null;
	}

	public DatosDeCobro getDatosDeCobro() {
		// TODO Auto-generated method stub
		return null;
	}

}
