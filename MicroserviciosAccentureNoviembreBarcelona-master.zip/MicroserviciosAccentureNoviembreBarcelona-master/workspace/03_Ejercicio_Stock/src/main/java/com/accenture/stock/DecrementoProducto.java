package com.accenture.stock;

public class DecrementoProducto {

	private String tipo;
	private int cantidad;
	
}
