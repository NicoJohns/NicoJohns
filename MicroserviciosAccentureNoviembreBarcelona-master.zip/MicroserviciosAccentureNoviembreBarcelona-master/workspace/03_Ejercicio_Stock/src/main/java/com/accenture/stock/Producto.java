package com.accenture.stock;

public class Producto {

}
